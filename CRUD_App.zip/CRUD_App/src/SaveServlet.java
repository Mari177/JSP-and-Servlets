import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
@WebServlet("/SaveServlet")
public class SaveServlet extends HttpServlet
{
	PrintWriter pw;
	protected void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		try
		{
			response.setContentType("text/html");
			pw=response.getWriter();
			String name=request.getParameter("name");
			String password=request.getParameter("password");
			String email=request.getParameter("email");
			String country=request.getParameter("country");
			Employee obj=new Employee();
			obj.setName(name);
			obj.setPassword(password);
			obj.setEmail(email);
			obj.setCountry(country);
			int status=Employee_Utils.save(obj);
			if(status>0)
			{
				pw.print("<p>Record saved successfully!</p>");
					request.getRequestDispatcher("index.html").include(request,response);
			}
			else
			{
				pw.println("Sorry! unable to save record");
			}
		}
		catch(Exception e)
		{
			System.err.println(e);
		}
		finally
		{
			pw.close();
		}
	}
}
	
		
		
		
