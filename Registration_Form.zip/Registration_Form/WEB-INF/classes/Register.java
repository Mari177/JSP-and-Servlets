import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServlet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
public class Register extends HttpServlet
{
	String userName,emailId,countryName;
	int age;
	Connection con;

	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		System.out.println("hi");
		response.setContentType("text/html");
		PrintWriter pws=response.getWriter();
		userName=request.getParameter("userName");
		age=Integer.parseInt(request.getParameter("userAge"));
		emailId=request.getParameter("userEmail");
		countryName=request.getParameter("userCountry");
		storeToDataBase(pws);
	}
	public void storeToDataBase(PrintWriter pw)
	{
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/TestDB","root","");
			PreparedStatement stmt=con.prepareStatement("insert into Person (Name,Age,Email_ID,Country) values(?,?,?,?)");
			stmt.setString(1, userName);
			stmt.setInt(2, age);
			stmt.setString(3, emailId);
			stmt.setString(4, countryName);
			int i=stmt.executeUpdate();
			if(i>0)
				pw.print("You have successfully registered...");
		}
		catch(Exception e)
		{
			pw.println("Message: "+e.getMessage());
			pw.println("Cause: "+e.getCause());
		}
		finally
		{
			try
			{
				con.close();
			}
			catch(Exception e)
			{}
		}
	}
	
}
		
			
			
