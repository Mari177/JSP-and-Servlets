import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletException;
public class DemoServlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		String name=req.getParameter("username");
		String password=req.getParameter("password");
		PrintWriter pws=res.getWriter();
		if(name.equals("admin")&&(password.equals("123")))
		{
			pws.print("Password is Correct");
		}
		else
		{
			pws.print("Given detail is wrong");
		}
	}
}
