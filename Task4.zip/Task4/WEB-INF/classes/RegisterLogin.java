import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.http.*;
import pack.*;
public class RegisterLogin extends HttpServlet{
    public void doGet(HttpServletRequest request, HttpServletResponse res) throws IOException
    {
        PrintWriter out=res.getWriter();
       System.out.println("Name " + request.getParameter("name"));
        String firstName=request.getParameter("name");
        out.println(request.getParameter("surname"));
        // String lastName=request.getParameter("surname");
        // String email=request.getParameter("email");
        // //long phoneNumber=Long.parseLong(request.getParameter("phonenumber"));
        // String password=request.getParameter("password");
        // //out.println(phoneNumber);
        // out.println(email);
        // out.println(lastName);
        /* int row=Register.DetailsUpdate(firstName,lastName,email,phoneNumber,password);
        if(row>0) 
            out.println("Succesfully registered");
        else
            out.println("Registration failed"); */
    }
}