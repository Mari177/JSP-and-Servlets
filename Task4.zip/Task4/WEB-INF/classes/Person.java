package pack;
public class Person
{
    private String firstName,surName,email;
    private long phoneNumber;
    private int id;
    private String password;
    public void setId(int id)
    {
        this.id=id;
    }
    public void setFirstName(String firstName)
    {
        this.firstName=firstName;
    }    
    public void setSurName(String surName)
    {
        this.surName=surName;
    }
    public void setEmail(String email)
    {
        this.email=email;
    }
    public void setPhoneNumber(long phoneNumber)
    {
        this.phoneNumber=phoneNumber;
    }
    public void setPassword(String password)
    {
        this.password=password;
    }
    public long getPhoneNumber()
    {
        return phoneNumber;
    }
    public String getPassword()
    {
        return password;
    }
    public String getFirstName()
    {
        return firstName;
    }
    public String getSurName()
    {
        return surName;
    }
    public String getEmail()
    {
        return email;
    }
    public int getPersonId()
    {
        return id;
    }

}
